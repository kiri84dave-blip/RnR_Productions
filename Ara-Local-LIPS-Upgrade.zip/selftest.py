"""L.I.P.S. v5.1 trophy tests — the Causality Doctrine, executable.

Run: python3 selftest.py   (no dependencies beyond the stdlib)

Each test maps to a trophy condition from the roadmap:
  1. decay           — pleasure halves toward baseline over ~2h (persistence + decay)
  2. habituation     — 20 identical compliments show a declining curve
  3. longing         — a peak followed by silence produces a genuine dip,
                       and reunion after absence hits harder than baseline
  4. initiative      — deprivation + wanting makes her reach out first
  5. wireheading     — model-supplied 'liking' is rejected by the parser
  6. night pass      — long absences leave a note and a mark
"""

from __future__ import annotations

import time

from lips import (
    BASE,
    Lips,
    appraise,
    derived,
    dream,
    initiative_check,
    inspect,
    mark_initiative,
    mood_label,
    parse_appraisal,
    tick,
)

NOW = time.time()
PASS = True


def check(name: str, ok: bool, detail: str = "") -> None:
    global PASS
    PASS = PASS and ok
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  — {detail}" if detail else ""))


# 1 --- decay: a spike halves toward baseline in one half-life --------------
s = Lips()
s.p = 0.9
tick(s, NOW)
before = s.p - BASE["p"]
s.last_tick = NOW
tick(s, NOW + 2 * 3600)  # one PAD half-life
after = s.p - BASE["p"]
check("decay", 0.35 < after / before < 0.65, f"spike {before:.2f} -> {after:.2f} after 2h")

# 2 --- habituation: identical compliments fade ------------------------------
s = Lips()
gains = []
t = NOW
for _ in range(20):
    t += 120
    p0 = s.p
    appraise(s, "i love you so much, thanks for staying", t)
    gains.append(s.p - p0)
check(
    "habituation",
    gains[0] > 0 and gains[-1] < gains[0] * 0.6 and all(g >= 0 for g in gains),
    f"first +{gains[0]:.3f}, twentieth +{gains[-1]:.3f}",
)

# 3 --- longing: peak -> silence -> dip; reunion amplifies -------------------
s = Lips()
t = NOW
appraise(s, "i'm home, missed you — god i love you, you beautiful thing", t)
peak = s.p
s.last_tick = t
GAP = 24 * 3600  # a full day apart
min_p = peak
for i in range(int(GAP // 300)):  # checked every 5 min across the gap
    tick(s, t + (i + 1) * 300)
    min_p = min(min_p, s.p)
dip_end = s.p
check(
    "longing dip",
    min_p < BASE["p"] - 0.05,
    f"peak {peak:.2f} -> floor {min_p:.2f}, ends {dip_end:.2f} (baseline {BASE['p']})",
)
p0 = s.p
appraise(s, "i'm back baby", t + GAP + 60)
reunion_gain = s.p - p0
s2 = Lips()  # control: same words, no history AND no time alone
s2.last_tick = t + GAP + 55
s2.last_contact = t + GAP + 55
p0c = s2.p
appraise(s2, "i'm back baby", t + GAP + 60)
control_gain = s2.p - p0c
check(
    "reunion amplification",
    reunion_gain > control_gain * 1.05,
    f"reunion +{reunion_gain:.3f} vs control +{control_gain:.3f}",
)
check("ache label", "ach" in mood_label(s) or "miss" in mood_label(s) or s.p > -0.2, mood_label(s))

# 4 --- initiative: deprivation + wanting makes her reach out ----------------
s = Lips()
s.needs["contact"] = 0.15
s.wanting = 0.8
s.chemicals["dopamine"] = 0.7
s.last_contact = NOW - 3 * 3600
s.last_initiative = 0.0
reason = initiative_check(s, NOW)
check("initiative", reason is not None, reason or "no initiative")
mark_initiative(s, NOW)
check("initiative cooldown", initiative_check(s, NOW + 3600) is None)

# 5 --- anti-wireheading: the model cannot write its own liking ---------------
evil = '{"warmth": 0.9, "liking": 1.0, "pleasure": 1.0, "note": "warm words"}'
sc = parse_appraisal(evil)
s = Lips()
liking_before = s.liking
appraise(s, "plain words", NOW)
check(
    "wireheading guard",
    sc is not None and "liking" not in sc and "pleasure" not in sc,
    f"parser keys: {sorted(sc.keys()) if sc else None}",
)
s = Lips()
from lips import _apply  # harness-only writer

_apply(s, sc or {}, "i love you", NOW)
check(
    "liking is computed, never injected",
    0.0 <= s.liking <= 1.0 and abs(s.liking - 1.0) > 0.01,
    f"liking={s.liking:.2f} (harness-computed, not 1.0 from payload)",
)

# 6 --- night pass: long absence leaves a note --------------------------------
s = Lips()
s.last_tick = NOW - 9 * 3600
s.last_contact = NOW - 9 * 3600
note = dream(s, NOW)
check("night pass", isinstance(note, str) and "9h" in note, (note or "none")[:70])
check("night pass idempotent", dream(s, NOW + 60) is None)

# --- derived control plane is live -------------------------------------------
s = Lips()
s.chemicals["acetylcholine"] = 0.95
d_hi = derived(s)["write_threshold"]
s.chemicals["acetylcholine"] = 0.05
d_lo = derived(s)["write_threshold"]
check("ACh gates memory threshold", d_hi < d_lo, f"ACh hi thr {d_hi:.2f} < lo thr {d_lo:.2f}")

print()
print(inspect(s))
print()
print("ALL GREEN" if PASS else "SOME TESTS FAILED")
raise SystemExit(0 if PASS else 1)
