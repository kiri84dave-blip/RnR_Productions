#!/usr/bin/env python3
r"""
Kokoro TTS HTTP Server for EvE 4.1BLESSED
Run with: C:\Users\georg\kokoro_env\Scripts\python.exe kokoro_server.py

Provides OpenAI-compatible /v1/audio/speech endpoint at localhost:8880
Used by EvE backend's /api/tts/kokoro/speak proxy endpoint.
"""
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import io
import sys

PORT = 8880

# ── Load pipeline at startup (blocks until ready) ──────────────────────
print("[Kokoro Server] Loading KPipeline (may take 5-10 seconds)...")
try:
    import numpy as np
    import soundfile as sf
    from kokoro import KPipeline
    pipeline = KPipeline(lang_code='a')   # 'a' = American English
    print("[Kokoro Server] KPipeline ready!")
except Exception as e:
    print(f"[Kokoro Server] FATAL: Could not load KPipeline: {e}", file=sys.stderr)
    print("[Kokoro Server] Make sure you're running in kokoro_env:", file=sys.stderr)
    print("  C:\\Users\\georg\\kokoro_env\\Scripts\\python.exe kokoro_server.py", file=sys.stderr)
    sys.exit(1)

SAMPLE_RATE = 24000

VOICES = {
    'af_heart', 'af_bella', 'af_nicole', 'af_sarah', 'af_sky',
    'am_michael', 'am_puck', 'am_echo', 'am_adam',
    'bf_emma', 'bf_isabella', 'bf_alice',
    'bm_george', 'bm_lewis',
}


class KokoroHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[Kokoro Server] {self.address_string()} {fmt % args}")

    # ── GET /health ──────────────────────────────────────────────────
    def do_GET(self):
        if self.path == "/health":
            self._json(200, {"status": "ok", "service": "kokoro-tts", "port": PORT})
        else:
            self._json(404, {"error": "not found"})

    # ── POST /v1/audio/speech ────────────────────────────────────────
    def do_POST(self):
        if self.path != "/v1/audio/speech":
            self._json(404, {"error": "not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length))
        except Exception as e:
            self._json(400, {"error": f"Bad request: {e}"})
            return

        text  = body.get("input", "").strip()
        voice = body.get("voice", "af_heart")
        speed = float(body.get("speed", 1.0))

        if not text:
            self._json(400, {"error": "input is required"})
            return

        if voice not in VOICES:
            voice = "af_bella"   # silent fallback to default voice

        try:
            # Generate all audio segments
            audio_chunks = []
            for segment in pipeline(text, voice=voice, speed=speed):
                audio_chunks.extend(segment.audio.detach().cpu().numpy())

            audio_array = np.array(audio_chunks, dtype=np.float32)

            # Encode as WAV in memory
            buf = io.BytesIO()
            sf.write(buf, audio_array, SAMPLE_RATE, format="WAV", subtype="PCM_16")
            wav_bytes = buf.getvalue()

            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(wav_bytes)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(wav_bytes)

        except Exception as e:
            print(f"[Kokoro Server] TTS error: {e}", file=sys.stderr)
            self._json(500, {"error": str(e)})

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _json(self, code, data):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", PORT), KokoroHandler)
    print(f"[Kokoro Server] Listening on http://localhost:{PORT}")
    print(f"[Kokoro Server] Health:  GET  http://localhost:{PORT}/health")
    print(f"[Kokoro Server] Speech:  POST http://localhost:{PORT}/v1/audio/speech")
    print(f"[Kokoro Server] Body: {{\"input\": \"Hello\", \"voice\": \"af_heart\", \"speed\": 1.0}}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[Kokoro Server] Shutting down...")
        server.shutdown()
