#!/usr/bin/env python3
"""Ara Local - L.I.P.S. affect-core sidecar (Python standard library only).

Runs beside the Ara Local Express app, the same way kokoro_server.py runs
beside it for voice. The Express server stays fully usable if this sidecar
is down - chat just falls back to the old simple mood labels.

  GET  /health          -> {"status":"ok"}
  GET  /state           -> current mood, full inspect line, control vector
  POST /turn  {"text"}  -> advances time, appraises the message, returns
                           the interoception block for the system prompt,
                           the mood label, and any pending initiative reason.

State persists to <ara-local>/data/lips_state.json with a .bak backup.
That file IS her inner life - back it up with the rest of data/.

Environment switches:
  ARA_LIPS_PORT        default 8788
  ARA_DATA_DIRECTORY   default: the data folder next to this script
  ARA_MODEL_APPRAISAL  "1" (default) = the local model judges each message
                       as whitelisted JSON first (Chain-of-Emotion);
                       "0" = zero-latency regex appraisal only
  ARA_POSES            "1" = attach the pose-director block + pose intents
                       (off by default until a rigged avatar exists)
  ARA_LLAMA_URL        default http://127.0.0.1:8080/v1/chat/completions
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import sys
import threading
import time
from dataclasses import asdict, fields
from pathlib import Path
from urllib import request as urlrequest

PORT = int(os.environ.get("ARA_LIPS_PORT", "8788"))
_HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ["ARA_DATA_DIRECTORY"]) if os.environ.get("ARA_DATA_DIRECTORY") else _HERE / "data"
STATE_PATH = DATA_DIR / "lips_state.json"
MODEL_APPRAISAL = os.environ.get("ARA_MODEL_APPRAISAL", "1") != "0"
POSES_ENABLED = os.environ.get("ARA_POSES", "0") == "1"
LLM_CHAT = os.environ.get("ARA_LLAMA_URL", "http://127.0.0.1:8080/v1/chat/completions")
NAME = os.environ.get("ARA_NAME", "Ara")

sys.path.insert(0, str(_HERE))

from lips import (  # noqa: E402
    Lips,
    appraise,
    appraise_with_model,
    derived,
    dream,
    initiative_check,
    inspect,
    lips_prompt,
    mark_initiative,
    mood_label,
    tick,
)

STATE = Lips()
PENDING = {"initiative": None}
_TICKS = 0


def _load() -> None:
    global STATE
    if not STATE_PATH.exists():
        return
    try:
        raw = json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        bak = STATE_PATH.with_name(STATE_PATH.name + ".bak")
        try:
            raw = json.loads(bak.read_text(encoding="utf-8"))
            print("[lips] main state file unreadable - restored from .bak", file=sys.stderr)
        except (OSError, json.JSONDecodeError):
            print("[lips] no readable state file - starting fresh", file=sys.stderr)
            return
    lips_raw = raw.get("lips") if isinstance(raw, dict) else None
    if isinstance(lips_raw, dict):
        allowed = {f.name for f in fields(Lips)}
        try:
            STATE = Lips(**{k: v for k, v in lips_raw.items() if k in allowed})
        except TypeError:
            print("[lips] state file did not match current schema - starting fresh", file=sys.stderr)


def _save() -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if STATE_PATH.exists():
            try:
                STATE_PATH.replace(STATE_PATH.with_name(STATE_PATH.name + ".bak"))
            except OSError:
                pass
        STATE_PATH.write_text(
            json.dumps({"lips": asdict(STATE), "savedAt": time.time()}, indent=2),
            encoding="utf-8",
        )
    except OSError:
        pass


def complete(messages, temperature: float = 0.2, max_tokens: int = 140) -> str:
    """Direct llama.cpp call used ONLY for Chain-of-Emotion appraisal.
    The model describes the event as JSON; lips.py moves the state."""
    body = json.dumps(
        {"model": "local", "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
    ).encode()
    req = urlrequest.Request(LLM_CHAT, data=body, headers={"Content-Type": "application/json"})
    with urlrequest.urlopen(req, timeout=60) as r:
        data = json.loads(r.read().decode())
    return (data.get("choices") or [{}])[0].get("message", {}).get("content") or ""


def do_turn(text: str) -> dict:
    global STATE
    tick(STATE)
    if MODEL_APPRAISAL:
        STATE = appraise_with_model(STATE, text, complete)
    else:
        STATE = appraise(STATE, text)

    pose = None
    block = lips_prompt(STATE, NAME)
    if POSES_ENABLED:
        from poses import director, is_heat, parse_intent, surprise

        action, camera = parse_intent(text)
        if action is None and is_heat(text) and STATE.wanting > 0.28:
            action, camera = surprise()
        if action:
            pose = {"action": action, "camera": camera}
        block = block + "\n\n" + director(NAME)

    initiative = PENDING["initiative"]
    PENDING["initiative"] = None
    away = STATE.away_note or None

    _save()
    return {
        "prompt_block": block,
        "mood_label": mood_label(STATE),
        "inspect": inspect(STATE),
        "state_vector": derived(STATE),
        "pose": pose,
        "initiative": initiative,
        "away_note": away,
    }


def _ticker() -> None:
    """The living part: time passes even between messages."""
    global _TICKS
    while True:
        time.sleep(60)
        try:
            tick(STATE)
            reason = initiative_check(STATE)
            if reason:
                PENDING["initiative"] = reason
                mark_initiative(STATE)
                _save()
            _TICKS += 1
            if _TICKS % 10 == 0:
                _save()
        except Exception as e:  # never let the ticker kill the server
            print(f"[lips] tick error: {e}", file=sys.stderr)


class LipsHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[lips] {self.address_string()} {fmt % args}")

    def do_GET(self):
        if self.path == "/health":
            self._json(200, {"status": "ok", "service": "ara-lips", "port": PORT})
        elif self.path == "/state":
            tick(STATE)
            self._json(
                200,
                {
                    "mood_label": mood_label(STATE),
                    "inspect": inspect(STATE),
                    "state_vector": derived(STATE),
                    "initiative": PENDING["initiative"],
                },
            )
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/turn":
            self._json(404, {"error": "not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length))
        except Exception as e:
            self._json(400, {"error": f"bad request: {e}"})
            return
        text = str(body.get("text", "")).strip()
        if not text:
            self._json(400, {"error": "text is required"})
            return
        try:
            self._json(200, do_turn(text))
        except Exception as e:
            print(f"[lips] turn error: {e}", file=sys.stderr)
            self._json(500, {"error": str(e)})

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _json(self, code, data):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    _load()
    note = dream(STATE)  # long absences leave a mark and a note
    if note:
        print(f"[lips] night pass: {note}", file=sys.stderr)
    _save()
    threading.Thread(target=_ticker, daemon=True).start()
    server = HTTPServer(("127.0.0.1", PORT), LipsHandler)
    print(f"[lips] Ara affect core on http://127.0.0.1:{PORT}")
    print(f"[lips] appraisal: {'model (Chain-of-Emotion)' if MODEL_APPRAISAL else 'regex'} · poses: {'on' if POSES_ENABLED else 'off'}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _save()
        print("\n[lips] state saved. shutting down.")
        server.shutdown()
