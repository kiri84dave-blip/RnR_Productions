@echo off
setlocal EnableExtensions

set "ARA_LOCAL_ROOT=%~dp0"
set "ARA_LOCAL_ROOT=%ARA_LOCAL_ROOT:~0,-1%"
cd /d "%ARA_LOCAL_ROOT%"

echo ========================================
echo Ara Local - Offline Companion Launcher
echo Project: %ARA_LOCAL_ROOT%
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found in this terminal.
  echo Install Node.js 20+ once, then run this file again.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo Preparing Ara Local for its first run...
  echo Downloading the locked local dependencies once. This requires an internet connection.
  call npm ci
  if errorlevel 1 (
    echo.
    echo ERROR: Ara Local could not install its local dependencies.
    echo Check your internet connection, then run this launcher again.
    pause
    exit /b 1
  )
)

set "LLAMA_SERVER=C:\llama.cpp\llama-server.exe"
set "LLAMA_MODEL=C:\Users\georg\Models\Gemma-4-E4B-Uncensored-HauhauCS-Aggressive-Q2_K_P\Gemma-4-E4B-Uncensored-HauhauCS-Aggressive-Q2_K_P.gguf"
set "ARA_LLAMA_DECISION="
for /f "tokens=1,2 delims==" %%A in ('node scripts\llama-launch-decision.mjs') do if /I "%%A"=="ARA_LLAMA_DECISION" set "ARA_LLAMA_DECISION=%%B"

if /I "%ARA_LLAMA_DECISION%"=="ready" (
  echo A local model server is already responding on http://127.0.0.1:8080.
) else if /I "%ARA_SKIP_LLAMA%"=="1" (
  echo Skipping automatic llama.cpp startup because ARA_SKIP_LLAMA=1.
) else if /I "%ARA_LLAMA_DECISION%"=="conflict" (
  echo WARNING: Another program occupies port 8080 but did not answer local model health checks.
  echo Ara Local will not start llama.cpp on that occupied port. Stop that program, then run this launcher again.
) else if exist "%LLAMA_SERVER%" if exist "%LLAMA_MODEL%" (
  echo Starting local llama.cpp on http://127.0.0.1:8080 ...
  start "Ara llama.cpp" /D "C:\llama.cpp" "%LLAMA_SERVER%" -m "%LLAMA_MODEL%" --host 127.0.0.1 --port 8080
  timeout /t 2 /nobreak >nul
) else (
  echo WARNING: llama.cpp executable or GGUF model was not found at the configured paths.
  echo Ara Local will still open and report model status.
)

REM ---- L.I.P.S. affect core (her inner life) ----
set "LIPS_PY=%ARA_LOCAL_ROOT%\lips_server.py"
if exist "%LIPS_PY%" (
  where py >nul 2>nul
  if not errorlevel 1 (
    echo Starting Ara affect core on http://127.0.0.1:8788 ...
    start "Ara L.I.P.S." /D "%ARA_LOCAL_ROOT%" py -3 "%LIPS_PY%"
  ) else (
    where python >nul 2>nul
    if not errorlevel 1 (
      echo Starting Ara affect core on http://127.0.0.1:8788 ...
      start "Ara L.I.P.S." /D "%ARA_LOCAL_ROOT%" python "%LIPS_PY%"
    ) else (
      echo NOTE: Python was not found, so the affect core is not running.
      echo Ara will still chat normally with simple mood labels.
    )
  )
)

REM ---- Optional: Kokoro voice on 127.0.0.1:8880 ----
REM Skip this if Kokoro already starts with your computer.
REM To enable:  set ARA_START_KOKORO=1  before running this launcher.
set "KOKORO_PY=C:\Users\georg\kokoro_env\Scripts\python.exe"
set "KOKORO_SCRIPT=%ARA_LOCAL_ROOT%\kokoro_server.py"
if /I "%ARA_START_KOKORO%"=="1" (
  if exist "%KOKORO_PY%" if exist "%KOKORO_SCRIPT%" (
    echo Starting Kokoro voice on http://127.0.0.1:8880 ...
    start "Ara Kokoro" /D "%ARA_LOCAL_ROOT%" "%KOKORO_PY%" "%KOKORO_SCRIPT%"
  ) else (
    echo WARNING: Kokoro was not started - kokoro_env python or kokoro_server.py not found.
  )
)

set "NODE_ENV=development"
set "PORT=3000"
echo Starting Ara Local. Keep this window open.
echo.
npm run dev

endlocal
