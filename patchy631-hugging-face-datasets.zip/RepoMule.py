#!/usr/bin/env python3
"""
HF Companion Suite v2 — Unified Desktop GUI
Hugging Face + GitHub bridge with plain language

Run:    python hf_companion_gui_v2.py
Requires: pip install huggingface_hub>=0.26.0 PyGithub
"""

import os
import sys
import shutil
import threading
import tempfile
import webbrowser
import zipfile
from pathlib import Path
from datetime import datetime
from tkinter import (
    Tk, ttk, messagebox, filedialog, scrolledtext,
    StringVar, Menu, Toplevel, Entry, Label, Button, Frame, Text, BOTH, X, Y, LEFT, RIGHT, TOP, BOTTOM
)

try:
    from huggingface_hub import (
        HfApi, whoami, login as hf_login,
        create_repo, delete_repo, move_repo, repo_info,
        upload_file, upload_folder, hf_hub_download, delete_file, snapshot_download,
        list_repo_tree, list_models, list_datasets, list_spaces,
        create_bucket, delete_bucket, list_buckets, list_bucket_tree,
        batch_bucket_files, download_bucket_files, get_bucket_file_metadata,
        CommitOperationCopy, CommitOperationDelete,
    )
except ImportError:
    messagebox.showerror("Missing Dependency", "pip install huggingface_hub>=0.26.0")
    sys.exit(1)

try:
    from github import Github, Auth
    HAS_GITHUB = True
except ImportError:
    HAS_GITHUB = False

api = HfApi()


# ── Helpers ──────────────────────────────────────────────────────────────────

def hsize(n):
    if n is None:
        return "—"
    for u in ['B', 'KB', 'MB', 'GB', 'TB']:
        if abs(n) < 1024:
            return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} PB"


def thread_it(fn, on_ok=None, on_err=None):
    def run():
        try:
            r = fn()
            if on_ok:
                on_ok(r)
        except Exception as e:
            if on_err:
                on_err(str(e))
    threading.Thread(target=run, daemon=True).start()


def ask_string(parent, title, prompt, default=""):
    top = Toplevel(parent)
    top.title(title)
    top.geometry("480x150")
    top.transient(parent)
    top.grab_set()
    Label(top, text=prompt, font=('Segoe UI', 10)).pack(pady=8, padx=10)
    ent = Entry(top, width=58, font=('Segoe UI', 10))
    ent.pack(padx=10)
    ent.insert(0, default)
    ent.select_range(0, "end")
    ent.focus()
    res = {"val": None}

    def ok():
        res["val"] = ent.get().strip()
        top.destroy()

    def cancel():
        top.destroy()

    bf = Frame(top)
    bf.pack(pady=10)
    Button(bf, text="OK", command=ok, width=12).pack(side=LEFT, padx=4)
    Button(bf, text="Cancel", command=cancel, width=12).pack(side=LEFT, padx=4)
    ent.bind("<Return>", lambda e: ok())
    parent.wait_window(top)
    return res["val"]


def ask_choice(parent, title, choices):
    top = Toplevel(parent)
    top.title(title)
    top.geometry("320x150")
    top.transient(parent)
    top.grab_set()
    Label(top, text=title, font=('Segoe UI', 10)).pack(pady=8)
    var = StringVar(value=choices[0] if choices else "")
    ttk.Combobox(top, textvariable=var, values=choices, state="readonly", width=30).pack(pady=6)
    res = {"val": None}

    def ok():
        res["val"] = var.get()
        top.destroy()

    Button(top, text="OK", command=ok, width=12).pack(pady=10)
    parent.wait_window(top)
    return res["val"]


# ── Main App ─────────────────────────────────────────────────────────────────

class HFCompanion:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title("HF Companion Suite v2")
        self.root.geometry("1450x920")
        self.root.minsize(1100, 720)

        self.clipboard = {"mode": None, "items": [], "source": None}
        self.user = None          # HF user dict
        self.gh = None            # Github client
        self.gh_user = None       # GitHub user login

        self._styles()
        self._menu()
        self._ui()
        self._auth_hf()

    # ── Styling ───────────────────────────────────────────────────────────────
    def _styles(self):
        s = ttk.Style()
        try:
            s.theme_use('vista')
        except Exception:
            s.theme_use('clam')
        s.configure("Treeview", rowheight=26, font=('Segoe UI', 10))
        s.configure("Treeview.Heading", font=('Segoe UI', 10, 'bold'))
        s.configure("TButton", padding=4, font=('Segoe UI', 9))
        s.configure("Accent.TButton", padding=5)

    # ── Menu ──────────────────────────────────────────────────────────────────
    def _menu(self):
        mb = Menu(self.root)
        m1 = Menu(mb, tearoff=0)
        m1.add_command(label="Login Hugging Face", command=self._login_hf)
        m1.add_command(label="Login GitHub", command=self._login_gh)
        m1.add_separator()
        m1.add_command(label="Whoami", command=self._whoami)
        m1.add_separator()
        m1.add_command(label="Exit", command=self.root.quit)
        mb.add_cascade(label="Account", menu=m1)

        m2 = Menu(mb, tearoff=0)
        m2.add_command(label="Copy", command=lambda: self._clip_op('copy'))
        m2.add_command(label="Cut", command=lambda: self._clip_op('cut'))
        m2.add_command(label="Paste", command=self._paste)
        mb.add_cascade(label="Edit", menu=m2)
        self.root.config(menu=mb)

    # ── UI Layout ─────────────────────────────────────────────────────────────
    def _ui(self):
        # Status bar (top)
        bar = Frame(self.root, bg="#1e1e1e", height=36)
        bar.pack(fill=X, side=TOP)
        bar.pack_propagate(False)

        self.status = StringVar(value="Ready")
        Label(bar, textvariable=self.status, bg="#1e1e1e", fg="#ddd",
              font=('Segoe UI', 10)).pack(side=LEFT, padx=12)

        self.account_var = StringVar(value="HF: not logged in  |  GitHub: not logged in")
        Label(bar, textvariable=self.account_var, bg="#1e1e1e", fg="#7fdbff",
              font=('Segoe UI', 9)).pack(side=RIGHT, padx=12)

        # Notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=BOTH, expand=True, padx=6, pady=4)

        self._build_hf_tab()
        self._build_github_tab()
        self._build_account_tab()

        # Log
        lf = Frame(self.root)
        lf.pack(fill=X, padx=6, pady=(0, 6), side=BOTTOM)
        Label(lf, text="Log", font=('Segoe UI', 9, 'bold')).pack(anchor="w")
        self.log = scrolledtext.ScrolledText(lf, height=7, state="disabled",
                                             wrap="word", font=('Consolas', 9))
        self.log.pack(fill=X)

    def _log(self, msg):
        self.log.configure(state="normal")
        self.log.insert("end", f"[{datetime.now():%H:%M:%S}] {msg}\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _set_status(self, t):
        self.status.set(t)
        self.root.update_idletasks()

    def _update_account_display(self):
        hf_part = "HF: not logged in"
        if self.user:
            name = self.user.get("name") or self.user.get("fullname") or ""
            uname = self.user.get("name") or self.user.get("username") or "?"
            email = self.user.get("email") or ""
            hf_part = f"HF: {uname}"
            if email:
                hf_part += f"  <{email}>"
            elif name and name != uname:
                hf_part += f"  ({name})"

        gh_part = "GitHub: not logged in"
        if self.gh_user:
            gh_part = f"GitHub: {self.gh_user}"

        self.account_var.set(f"{hf_part}   |   {gh_part}")

    # ── Auth ──────────────────────────────────────────────────────────────────
    def _auth_hf(self):
        def do():
            try:
                self.user = whoami()
                self._update_account_display()
                self._log(f"HF connected as {self.user.get('name') or self.user.get('username')}")
                self.root.after(0, self._refresh_hf)
            except Exception as e:
                self._log(f"HF not logged in yet: {e}")
        thread_it(do)

    def _login_hf(self):
        def do():
            try:
                hf_login()
                self.user = whoami()
                self._update_account_display()
                self._log("HF login OK")
                self.root.after(0, self._refresh_hf)
            except Exception as e:
                self._log(f"HF login failed: {e}")
        thread_it(do)

    def _login_gh(self):
        if not HAS_GITHUB:
            messagebox.showinfo("GitHub", "Install PyGithub first:\npip install PyGithub")
            return
        token = ask_string(self.root, "GitHub Token",
                           "Paste a GitHub Personal Access Token (repo scope):")
        if not token:
            return

        def do():
            try:
                auth = Auth.Token(token)
                self.gh = Github(auth=auth)
                user = self.gh.get_user()
                self.gh_user = user.login
                # cache token lightly for the session
                self._gh_token = token
                self._update_account_display()
                self._log(f"GitHub connected as {self.gh_user}")
                self.root.after(0, self._refresh_gh_repos)
            except Exception as e:
                self._log(f"GitHub login failed: {e}")
        thread_it(do)

    def _whoami(self):
        lines = []
        if self.user:
            lines.append(f"HF username : {self.user.get('name') or self.user.get('username')}")
            lines.append(f"HF email    : {self.user.get('email') or '—'}")
            lines.append(f"HF orgs     : {', '.join(self.user.get('orgs', []) or ['none'])}")
        else:
            lines.append("HF: not logged in")
        lines.append("")
        if self.gh_user:
            lines.append(f"GitHub      : {self.gh_user}")
        else:
            lines.append("GitHub: not logged in")
        messagebox.showinfo("Current Accounts", "\n".join(lines))

    def _refresh_hf(self):
        self._refresh_models()
        self._refresh_buckets()
        self._refresh_spaces()

    # ═══════════════════════════════════════════════════════════════════════════
    #  HUGGING FACE TAB
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_hf_tab(self):
        tab = Frame(self.notebook)
        self.notebook.add(tab, text="  Hugging Face  ")

        # Sub-notebook for Models / Buckets / Spaces
        self.hf_nb = ttk.Notebook(tab)
        self.hf_nb.pack(fill=BOTH, expand=True, padx=4, pady=4)

        self._build_models_sub(self.hf_nb)
        self._build_buckets_sub(self.hf_nb)
        self._build_spaces_sub(self.hf_nb)

    def _build_models_sub(self, parent):
        sub = Frame(parent)
        parent.add(sub, text="  Models  ")

        tb = Frame(sub)
        tb.pack(fill=X, pady=2)
        Button(tb, text="🔄 Refresh", command=self._refresh_models).pack(side=LEFT, padx=2)
        Button(tb, text="➕ New Model", command=self._repo_create_model).pack(side=LEFT, padx=2)
        Button(tb, text="📥 Download", command=lambda: self._download('model')).pack(side=LEFT, padx=2)
        Button(tb, text="📤 Upload", command=lambda: self._upload('model')).pack(side=LEFT, padx=2)
        Button(tb, text="✏ Rename", command=lambda: self._rename('model')).pack(side=LEFT, padx=2)
        Button(tb, text="🗑 Delete", command=lambda: self._delete('model')).pack(side=LEFT, padx=2)

        paned = ttk.PanedWindow(sub, orient="horizontal")
        paned.pack(fill=BOTH, expand=True, pady=4)

        left = Frame(paned)
        Label(left, text="Your Models", font=('Segoe UI', 10, 'bold')).pack(anchor="w", padx=4)
        self.model_list = ttk.Treeview(left, show="tree", selectmode="browse")
        self.model_list.pack(fill=BOTH, expand=True, padx=4)
        self.model_list.bind("<<TreeviewSelect>>", lambda e: self._load_repo_tree('model'))
        paned.add(left, weight=1)

        right = Frame(paned)
        Label(right, text="Files", font=('Segoe UI', 10, 'bold')).pack(anchor="w", padx=4)
        self.model_tree = ttk.Treeview(right, columns=("size", "kind"),
                                       show="tree headings", selectmode="extended")
        self.model_tree.heading("#0", text="Name")
        self.model_tree.heading("size", text="Size")
        self.model_tree.heading("kind", text="Type")
        self.model_tree.pack(fill=BOTH, expand=True)
        self.model_tree.bind("<Button-3>", lambda e: self._ctx_menu(e, 'model'))
        paned.add(right, weight=3)

    def _build_buckets_sub(self, parent):
        sub = Frame(parent)
        parent.add(sub, text="  Buckets  ")

        tb = Frame(sub)
        tb.pack(fill=X, pady=2)
        Button(tb, text="🔄 Refresh", command=self._refresh_buckets).pack(side=LEFT, padx=2)
        Button(tb, text="➕ New Bucket", command=self._bucket_create).pack(side=LEFT, padx=2)
        Button(tb, text="📥 Download", command=lambda: self._download('bucket')).pack(side=LEFT, padx=2)
        Button(tb, text="📤 Upload", command=lambda: self._upload('bucket')).pack(side=LEFT, padx=2)
        Button(tb, text="✏ Rename", command=lambda: self._rename('bucket')).pack(side=LEFT, padx=2)
        Button(tb, text="🗑 Delete", command=lambda: self._delete('bucket')).pack(side=LEFT, padx=2)

        paned = ttk.PanedWindow(sub, orient="horizontal")
        paned.pack(fill=BOTH, expand=True, pady=4)

        left = Frame(paned)
        Label(left, text="Your Buckets", font=('Segoe UI', 10, 'bold')).pack(anchor="w", padx=4)
        self.bucket_list = ttk.Treeview(left, show="tree", selectmode="browse")
        self.bucket_list.pack(fill=BOTH, expand=True, padx=4)
        self.bucket_list.bind("<<TreeviewSelect>>", lambda e: self._load_bucket_tree())
        paned.add(left, weight=1)

        right = Frame(paned)
        Label(right, text="Files", font=('Segoe UI', 10, 'bold')).pack(anchor="w", padx=4)
        self.bucket_tree = ttk.Treeview(right, columns=("size", "kind"),
                                        show="tree headings", selectmode="extended")
        self.bucket_tree.heading("#0", text="Name")
        self.bucket_tree.heading("size", text="Size")
        self.bucket_tree.heading("kind", text="Type")
        self.bucket_tree.pack(fill=BOTH, expand=True)
        self.bucket_tree.bind("<Button-3>", lambda e: self._ctx_menu(e, 'bucket'))
        paned.add(right, weight=3)

    def _build_spaces_sub(self, parent):
        sub = Frame(parent)
        parent.add(sub, text="  Spaces  ")

        tb = Frame(sub)
        tb.pack(fill=X, pady=2)
        Button(tb, text="🔄 Refresh", command=self._refresh_spaces).pack(side=LEFT, padx=2)
        Button(tb, text="⚙ Open Settings", command=self._space_settings).pack(side=LEFT, padx=2)

        self.space_tree = ttk.Treeview(sub, columns=("likes",), show="tree headings")
        self.space_tree.heading("#0", text="Space ID")
        self.space_tree.heading("likes", text="Likes")
        self.space_tree.pack(fill=BOTH, expand=True, padx=4, pady=4)

    # ── HF data loaders ───────────────────────────────────────────────────────
    def _refresh_models(self):
        if not self.user:
            return
        self._set_status("Loading models...")

        def load():
            ns = self.user.get("name") or self.user.get("username")
            return [("model", m.id) for m in list_models(author=ns)]

        def ok(repos):
            self.model_list.delete(*self.model_list.get_children())
            self._model_map = {}
            for t, rid in sorted(repos, key=lambda x: x[1]):
                nid = self.model_list.insert("", "end", text=f"🤖 {rid}")
                self._model_map[nid] = (t, rid)
            self._set_status(f"{len(repos)} models")
            self._log(f"Loaded {len(repos)} models")

        thread_it(load, ok, lambda e: (self._set_status("Error"), self._log(e)))

    def _refresh_buckets(self):
        if not self.user:
            return
        self._set_status("Loading buckets...")

        def load():
            ns = self.user.get("name") or self.user.get("username")
            return list(list_buckets(namespace=ns))

        def ok(buckets):
            self.bucket_list.delete(*self.bucket_list.get_children())
            self._bucket_map = {}
            for b in buckets:
                icon = "🔒" if b.private else "🌐"
                nid = self.bucket_list.insert("", "end", text=f"{icon} {b.id}")
                self._bucket_map[nid] = b.id
            self._set_status(f"{len(buckets)} buckets")
            self._log(f"Loaded {len(buckets)} buckets")

        thread_it(load, ok, lambda e: (self._set_status("Error"), self._log(e)))

    def _refresh_spaces(self):
        if not self.user:
            return

        def load():
            ns = self.user.get("name") or self.user.get("username")
            return list(list_spaces(author=ns))

        def ok(spaces):
            self.space_tree.delete(*self.space_tree.get_children())
            for s in spaces:
                self.space_tree.insert("", "end", text=s.id,
                                       values=(getattr(s, 'likes', 0),))
            self._log(f"Loaded {len(spaces)} spaces")

        thread_it(load, ok, lambda e: self._log(str(e)))

    def _selected_model(self):
        sel = self.model_list.selection()
        if not sel:
            return None
        return self._model_map.get(sel[0])

    def _selected_bucket(self):
        sel = self.bucket_list.selection()
        if not sel:
            return None
        return self._bucket_map.get(sel[0])

    def _load_repo_tree(self, kind='model'):
        repo = self._selected_model()
        if not repo:
            return
        t, rid = repo
        self._set_status(f"Loading {rid}...")
        tree = self.model_tree
        tree.delete(*tree.get_children())

        def load():
            return list(list_repo_tree(rid, repo_type=t, recursive=True))

        def ok(items):
            nodes = {}
            for item in items:
                p = item.path
                parts = p.split("/")
                parent = ""
                for part in parts[:-1]:
                    cur = f"{parent}/{part}" if parent else part
                    if cur not in nodes:
                        nodes[cur] = tree.insert(parent, "end", text=part,
                                                 values=("", "📁"), open=False)
                    parent = nodes[cur]
                if hasattr(item, 'size'):
                    tree.insert(parent, "end", text=parts[-1],
                                values=(hsize(item.size), "📄"))
                else:
                    nodes[p] = tree.insert(parent, "end", text=parts[-1],
                                           values=("", "📁"), open=False)
            self._set_status("Ready")

        thread_it(load, ok, lambda e: (self._set_status("Error"), self._log(e)))

    def _load_bucket_tree(self):
        bid = self._selected_bucket()
        if not bid:
            return
        self._set_status(f"Loading {bid}...")
        self.bucket_tree.delete(*self.bucket_tree.get_children())

        def load():
            return list(list_bucket_tree(bid, recursive=True))

        def ok(items):
            nodes = {}
            for item in items:
                p = item.path
                parts = p.split("/")
                parent = ""
                for part in parts[:-1]:
                    cur = f"{parent}/{part}" if parent else part
                    if cur not in nodes:
                        nodes[cur] = self.bucket_tree.insert(parent, "end", text=part,
                                                             values=("", "📁"), open=False)
                    parent = nodes[cur]
                if hasattr(item, 'size'):
                    self.bucket_tree.insert(parent, "end", text=parts[-1],
                                            values=(hsize(item.size), "📄"))
                else:
                    nodes[p] = self.bucket_tree.insert(parent, "end", text=parts[-1],
                                                       values=("", "📁"), open=False)
            self._set_status("Ready")

        thread_it(load, ok, lambda e: (self._set_status("Error"), self._log(e)))

    def _space_settings(self):
        sel = self.space_tree.selection()
        if not sel:
            return
        sid = self.space_tree.item(sel[0], "text")
        webbrowser.open(f"https://huggingface.co/spaces/{sid}/settings")

    # ═══════════════════════════════════════════════════════════════════════════
    #  GITHUB TAB
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_github_tab(self):
        tab = Frame(self.notebook)
        self.notebook.add(tab, text="  GitHub  ")

        # Top actions
        top = Frame(tab)
        top.pack(fill=X, pady=4, padx=4)

        Label(top, text="GitHub Bridge", font=('Segoe UI', 11, 'bold')).pack(side=LEFT, padx=4)

        Button(top, text="🔑 Login GitHub", command=self._login_gh).pack(side=LEFT, padx=4)
        Button(top, text="🔄 Refresh Repos", command=self._refresh_gh_repos).pack(side=LEFT, padx=4)

        # Main split
        paned = ttk.PanedWindow(tab, orient="horizontal")
        paned.pack(fill=BOTH, expand=True, padx=4, pady=4)

        # Left: GitHub repos
        left = Frame(paned)
        Label(left, text="Your GitHub Repos", font=('Segoe UI', 10, 'bold')).pack(anchor="w")
        self.gh_list = ttk.Treeview(left, show="tree", selectmode="browse")
        self.gh_list.pack(fill=BOTH, expand=True)
        self.gh_list.bind("<<TreeviewSelect>>", lambda e: self._load_gh_tree())
        paned.add(left, weight=1)

        # Right: files + action buttons
        right = Frame(paned)
        Label(right, text="Files in selected repo", font=('Segoe UI', 10, 'bold')).pack(anchor="w")

        self.gh_tree = ttk.Treeview(right, columns=("size", "kind"),
                                    show="tree headings", selectmode="extended")
        self.gh_tree.heading("#0", text="Name")
        self.gh_tree.heading("size", text="Size")
        self.gh_tree.heading("kind", text="Type")
        self.gh_tree.pack(fill=BOTH, expand=True)

        # Action buttons – plain language
        act = Frame(right)
        act.pack(fill=X, pady=6)

        Label(act, text="Actions (plain language):", font=('Segoe UI', 9, 'bold')).pack(anchor="w")

        row1 = Frame(act)
        row1.pack(fill=X, pady=2)
        Button(row1, text="📥 Get from GitHub → local folder",
               command=self._gh_get_to_local, width=32).pack(side=LEFT, padx=2)
        Button(row1, text="📤 Send local folder/file → GitHub",
               command=self._gh_send_local, width=32).pack(side=LEFT, padx=2)

        row2 = Frame(act)
        row2.pack(fill=X, pady=2)
        Button(row2, text="➡ Send GitHub repo → Hugging Face",
               command=self._gh_to_hf, width=32).pack(side=LEFT, padx=2)
        Button(row2, text="⬅ Send Hugging Face → GitHub",
               command=self._hf_to_gh, width=32).pack(side=LEFT, padx=2)

        row3 = Frame(act)
        row3.pack(fill=X, pady=2)
        Button(row3, text="📦 Make ZIP of GitHub repo (for download)",
               command=self._gh_make_zip, width=40).pack(side=LEFT, padx=2)

        paned.add(right, weight=3)

        # Notes
        note = Label(tab, text=(
            "Rules:  To Hugging Face = files or folders only (no zips).  "
            "To GitHub = files, folders, whole repos, or zips."
        ), font=('Segoe UI', 8), fg="#666")
        note.pack(anchor="w", padx=8, pady=2)

    def _refresh_gh_repos(self):
        if not self.gh:
            self._log("GitHub not logged in")
            return
        self._set_status("Loading GitHub repos...")

        def load():
            user = self.gh.get_user()
            return list(user.get_repos())

        def ok(repos):
            self.gh_list.delete(*self.gh_list.get_children())
            self._gh_map = {}
            for r in sorted(repos, key=lambda x: x.full_name.lower()):
                nid = self.gh_list.insert("", "end", text=r.full_name)
                self._gh_map[nid] = r
            self._set_status(f"{len(repos)} GitHub repos")
            self._log(f"Loaded {len(repos)} GitHub repos")

        thread_it(load, ok, lambda e: (self._set_status("Error"), self._log(e)))

    def _selected_gh_repo(self):
        sel = self.gh_list.selection()
        if not sel:
            return None
        return self._gh_map.get(sel[0])

    def _load_gh_tree(self):
        repo = self._selected_gh_repo()
        if not repo:
            return
        self._set_status(f"Loading {repo.full_name}...")
        self.gh_tree.delete(*self.gh_tree.get_children())

        def load():
            # Get root contents; for simplicity we show top level + one level deep
            contents = repo.get_contents("")
            items = []
            for c in contents:
                items.append(c)
                if c.type == "dir":
                    try:
                        for sub in repo.get_contents(c.path):
                            items.append(sub)
                    except Exception:
                        pass
            return items

        def ok(items):
            nodes = {"": ""}
            for c in items:
                parts = c.path.split("/")
                parent = ""
                for i, part in enumerate(parts[:-1]):
                    cur = "/".join(parts[:i+1])
                    if cur not in nodes:
                        nodes[cur] = self.gh_tree.insert(nodes.get(parent, ""), "end",
                                                         text=part, values=("", "📁"), open=False)
                    parent = cur
                kind = "📁" if c.type == "dir" else "📄"
                size = hsize(c.size) if c.type == "file" else ""
                self.gh_tree.insert(nodes.get(parent, ""), "end", text=parts[-1],
                                    values=(size, kind))
            self._set_status("Ready")

        thread_it(load, ok, lambda e: (self._set_status("Error"), self._log(e)))

    # ── GitHub actions (plain language) ───────────────────────────────────────
    def _gh_get_to_local(self):
        """Download selected GitHub repo (or selected files) to a local folder."""
        repo = self._selected_gh_repo()
        if not repo:
            messagebox.showwarning("Select", "Select a GitHub repo first")
            return
        dst = filedialog.askdirectory(title="Save GitHub content to folder")
        if not dst:
            return

        def do():
            self._set_status(f"Getting {repo.full_name}...")
            # Simple: clone via zipball
            import urllib.request
            url = f"https://github.com/{repo.full_name}/archive/refs/heads/{repo.default_branch}.zip"
            zip_path = os.path.join(dst, f"{repo.name}.zip")
            # Prefer authenticated download if we have token
            try:
                # Use PyGithub content download for better auth
                contents = repo.get_contents("")
                for c in contents:
                    self._download_gh_content(repo, c, dst)
            except Exception as e:
                self._log(f"Fallback zip download: {e}")
                urllib.request.urlretrieve(url, zip_path)
            self._set_status("Done")
            self._log(f"Got {repo.full_name} → {dst}")

        thread_it(do, on_err=lambda e: self._log(f"Get failed: {e}"))

    def _download_gh_content(self, repo, content, base_dir):
        path = os.path.join(base_dir, content.path)
        if content.type == "dir":
            os.makedirs(path, exist_ok=True)
            for sub in repo.get_contents(content.path):
                self._download_gh_content(repo, sub, base_dir)
        else:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as f:
                f.write(content.decoded_content)

    def _gh_send_local(self):
        """Send a local file or folder to the selected GitHub repo."""
        repo = self._selected_gh_repo()
        if not repo:
            messagebox.showwarning("Select", "Select a GitHub repo first")
            return
        local = filedialog.askopenfilename(title="Select file (or cancel and choose folder)")
        if not local:
            local = filedialog.askdirectory(title="Select folder to send")
        if not local:
            return

        def do():
            self._set_status("Sending to GitHub...")
            p = Path(local)
            if p.is_file():
                with open(p, "rb") as f:
                    data = f.read()
                try:
                    repo.create_file(p.name, f"Add {p.name} via HF Companion", data)
                except Exception:
                    # file exists → update
                    contents = repo.get_contents(p.name)
                    repo.update_file(p.name, f"Update {p.name} via HF Companion", data, contents.sha)
            else:
                for f in p.rglob("*"):
                    if f.is_file():
                        rel = str(f.relative_to(p)).replace("\\", "/")
                        with open(f, "rb") as fh:
                            data = fh.read()
                        try:
                            repo.create_file(rel, f"Add {rel} via HF Companion", data)
                        except Exception:
                            try:
                                contents = repo.get_contents(rel)
                                repo.update_file(rel, f"Update {rel}", data, contents.sha)
                            except Exception as e:
                                self._log(f"Skip {rel}: {e}")
            self._set_status("Done")
            self._log(f"Sent {local} → {repo.full_name}")
            self.root.after(0, self._load_gh_tree)

        thread_it(do, on_err=lambda e: self._log(f"Send failed: {e}"))

    def _gh_to_hf(self):
        """Send a GitHub repo (as folder contents) to a Hugging Face model or bucket."""
        repo = self._selected_gh_repo()
        if not repo:
            messagebox.showwarning("Select", "Select a GitHub repo first")
            return
        if not self.user:
            messagebox.showwarning("HF", "Login to Hugging Face first")
            return

        target_type = ask_choice(self.root, "Send to Hugging Face",
                                 ["model", "bucket"])
        if not target_type:
            return

        if target_type == "model":
            rid = ask_string(self.root, "HF Model ID",
                             "Target model ID (user/name):",
                             default=f"{self.user.get('name') or self.user.get('username')}/{repo.name}")
            if not rid:
                return
        else:
            bid = ask_string(self.root, "HF Bucket ID",
                             "Target bucket ID:",
                             default=f"{self.user.get('name') or self.user.get('username')}/{repo.name}")
            if not bid:
                return

        def do():
            self._set_status("Sending GitHub → HF...")
            tmp = tempfile.mkdtemp()
            try:
                contents = repo.get_contents("")
                for c in contents:
                    self._download_gh_content(repo, c, tmp)

                if target_type == "model":
                    # create if needed
                    try:
                        create_repo(rid, repo_type="model", exist_ok=True)
                    except Exception:
                        pass
                    upload_folder(folder_path=tmp, repo_id=rid, repo_type="model",
                                  commit_message=f"From GitHub {repo.full_name} via Companion")
                    self._log(f"Sent {repo.full_name} → HF model {rid}")
                else:
                    try:
                        create_bucket(bid, exist_ok=True)
                    except Exception:
                        pass
                    files = []
                    for f in Path(tmp).rglob("*"):
                        if f.is_file():
                            rel = str(f.relative_to(tmp)).replace("\\", "/")
                            files.append((str(f), rel))
                    if files:
                        batch_bucket_files(bid, add=files)
                    self._log(f"Sent {repo.full_name} → HF bucket {bid}")
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            self._set_status("Done")

        thread_it(do, on_err=lambda e: self._log(f"GH→HF failed: {e}"))

    def _hf_to_gh(self):
        """Send an HF model or bucket into a GitHub repo."""
        if not self.gh:
            messagebox.showwarning("GitHub", "Login to GitHub first")
            return

        # Ask source
        src_type = ask_choice(self.root, "Source on Hugging Face", ["model", "bucket"])
        if not src_type:
            return

        if src_type == "model":
            rid = ask_string(self.root, "HF Model", "Model ID to send:")
            if not rid:
                return
        else:
            bid = ask_string(self.root, "HF Bucket", "Bucket ID to send:")
            if not bid:
                return

        # Target GitHub repo
        gh_name = ask_string(self.root, "GitHub Repo",
                             "Target GitHub repo (user/name) — will create if missing:")
        if not gh_name:
            return

        def do():
            self._set_status("Sending HF → GitHub...")
            tmp = tempfile.mkdtemp()
            try:
                if src_type == "model":
                    snapshot_download(rid, local_dir=tmp, repo_type="model")
                else:
                    items = list(list_bucket_tree(bid, recursive=True))
                    for it in items:
                        if hasattr(it, 'size'):
                            local_f = os.path.join(tmp, it.path)
                            os.makedirs(os.path.dirname(local_f), exist_ok=True)
                            download_bucket_files(bid, files=[(it.path, local_f)])

                # Ensure GitHub repo exists
                try:
                    repo = self.gh.get_repo(gh_name)
                except Exception:
                    user = self.gh.get_user()
                    name = gh_name.split("/")[-1]
                    repo = user.create_repo(name, private=True)
                    self._log(f"Created GitHub repo {repo.full_name}")

                # Upload files
                for f in Path(tmp).rglob("*"):
                    if f.is_file():
                        rel = str(f.relative_to(tmp)).replace("\\", "/")
                        with open(f, "rb") as fh:
                            data = fh.read()
                        try:
                            repo.create_file(rel, f"From HF via Companion", data)
                        except Exception:
                            try:
                                contents = repo.get_contents(rel)
                                repo.update_file(rel, f"Update from HF", data, contents.sha)
                            except Exception as e:
                                self._log(f"Skip {rel}: {e}")

                self._log(f"Sent HF → GitHub {repo.full_name}")
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            self._set_status("Done")
            self.root.after(0, self._refresh_gh_repos)

        thread_it(do, on_err=lambda e: self._log(f"HF→GH failed: {e}"))

    def _gh_make_zip(self):
        """Download the selected GitHub repo as a zip file (with README etc.)."""
        repo = self._selected_gh_repo()
        if not repo:
            messagebox.showwarning("Select", "Select a GitHub repo first")
            return
        dst = filedialog.asksaveasfilename(
            title="Save zip as",
            defaultextension=".zip",
            initialfile=f"{repo.name}.zip",
            filetypes=[("Zip files", "*.zip")]
        )
        if not dst:
            return

        def do():
            self._set_status("Making zip...")
            tmp = tempfile.mkdtemp()
            try:
                contents = repo.get_contents("")
                for c in contents:
                    self._download_gh_content(repo, c, tmp)
                with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zf:
                    for f in Path(tmp).rglob("*"):
                        if f.is_file():
                            zf.write(f, f.relative_to(tmp))
                self._log(f"Zip saved: {dst}")
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            self._set_status("Done")

        thread_it(do, on_err=lambda e: self._log(f"Zip failed: {e}"))

    # ═══════════════════════════════════════════════════════════════════════════
    #  ACCOUNT TAB
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_account_tab(self):
        tab = Frame(self.notebook)
        self.notebook.add(tab, text="  Account  ")

        Label(tab, text="Account Status", font=('Segoe UI', 12, 'bold')).pack(anchor="w", padx=12, pady=8)

        self.account_detail = Label(tab, text="Loading...", justify="left",
                                    font=('Segoe UI', 10), anchor="w")
        self.account_detail.pack(anchor="w", padx=12, pady=4)

        bf = Frame(tab)
        bf.pack(anchor="w", padx=12, pady=12)
        Button(bf, text="Login Hugging Face", command=self._login_hf, width=22).pack(side=LEFT, padx=4)
        Button(bf, text="Login GitHub", command=self._login_gh, width=18).pack(side=LEFT, padx=4)
        Button(bf, text="Refresh Status", command=self._refresh_account_tab, width=16).pack(side=LEFT, padx=4)

        Label(tab, text=(
            "Tip: Login uses your browser. Whatever account is active in the browser\n"
            "is the one the app will use. Check the top bar to confirm which account is live."
        ), justify="left", font=('Segoe UI', 9), fg="#555").pack(anchor="w", padx=12, pady=8)

    def _refresh_account_tab(self):
        lines = []
        if self.user:
            lines.append(f"Hugging Face")
            lines.append(f"  Username : {self.user.get('name') or self.user.get('username')}")
            lines.append(f"  Email    : {self.user.get('email') or '—'}")
            lines.append(f"  Name     : {self.user.get('fullname') or self.user.get('name') or '—'}")
        else:
            lines.append("Hugging Face: not logged in")
        lines.append("")
        if self.gh_user:
            lines.append(f"GitHub")
            lines.append(f"  Login    : {self.gh_user}")
        else:
            lines.append("GitHub: not logged in")
        self.account_detail.config(text="\n".join(lines))
        self._update_account_display()

    # ═══════════════════════════════════════════════════════════════════════════
    #  SHARED ACTIONS (download / upload / rename / delete)
    # ═══════════════════════════════════════════════════════════════════════════
    def _ctx_menu(self, event, kind):
        menu = Menu(self.root, tearoff=0)
        menu.add_command(label="📥 Download", command=lambda: self._download(kind))
        menu.add_command(label="📤 Upload", command=lambda: self._upload(kind))
        menu.add_command(label="✏ Rename", command=lambda: self._rename(kind))
        menu.add_command(label="🗑 Delete", command=lambda: self._delete(kind))
        menu.post(event.x_root, event.y_root)

    def _download(self, kind):
        if kind == 'model':
            repo = self._selected_model()
            if not repo:
                messagebox.showwarning("Select", "Select a model first")
                return
            t, rid = repo
            dst = filedialog.askdirectory(title="Download to folder")
            if not dst:
                return

            def do():
                self._set_status(f"Downloading {rid}...")
                snapshot_download(rid, repo_type=t, local_dir=dst)
                self._set_status("Done")
                self._log(f"Downloaded {rid} → {dst}")

            thread_it(do, on_err=lambda e: self._log(f"Download error: {e}"))

        elif kind == 'bucket':
            bid = self._selected_bucket()
            if not bid:
                messagebox.showwarning("Select", "Select a bucket first")
                return
            dst = filedialog.askdirectory(title="Download to folder")
            if not dst:
                return

            def do():
                self._set_status(f"Downloading bucket {bid}...")
                items = list(list_bucket_tree(bid, recursive=True))
                for it in items:
                    if hasattr(it, 'size'):
                        local_f = os.path.join(dst, it.path)
                        os.makedirs(os.path.dirname(local_f), exist_ok=True)
                        download_bucket_files(bid, files=[(it.path, local_f)])
                self._set_status("Done")
                self._log(f"Downloaded bucket {bid} → {dst}")

            thread_it(do, on_err=lambda e: self._log(f"Download error: {e}"))

    def _upload(self, kind):
        if kind == 'model':
            repo = self._selected_model()
            if not repo:
                messagebox.showwarning("Select", "Select a model first")
                return
            t, rid = repo
            local = filedialog.askopenfilename(title="Select file to upload")
            if not local:
                local = filedialog.askdirectory(title="Or select folder")
            if not local:
                return

            def do():
                self._set_status("Uploading...")
                p = Path(local)
                if p.is_file():
                    upload_file(path_or_fileobj=str(p), repo_id=rid,
                                path_in_repo=p.name, repo_type=t)
                else:
                    upload_folder(folder_path=str(p), repo_id=rid, repo_type=t)
                self._set_status("Done")
                self._log(f"Uploaded → {rid}")
                self.root.after(0, lambda: self._load_repo_tree('model'))

            thread_it(do, on_err=lambda e: self._log(f"Upload error: {e}"))

        elif kind == 'bucket':
            bid = self._selected_bucket()
            if not bid:
                messagebox.showwarning("Select", "Select a bucket first")
                return
            local = filedialog.askopenfilename(title="Select file")
            if not local:
                local = filedialog.askdirectory(title="Or select folder")
            if not local:
                return

            def do():
                self._set_status("Uploading to bucket...")
                p = Path(local)
                if p.is_file():
                    batch_bucket_files(bid, add=[(str(p), p.name)])
                else:
                    files = []
                    for f in p.rglob("*"):
                        if f.is_file():
                            rel = str(f.relative_to(p)).replace("\\", "/")
                            files.append((str(f), rel))
                    if files:
                        batch_bucket_files(bid, add=files)
                self._set_status("Done")
                self._log(f"Uploaded → bucket {bid}")
                self.root.after(0, self._load_bucket_tree)

            thread_it(do, on_err=lambda e: self._log(f"Upload error: {e}"))

    def _rename(self, kind):
        messagebox.showinfo("Rename", "Select the file in the tree, then use the Rename button.\n(Full path rename coming in next polish pass.)")

    def _delete(self, kind):
        if kind == 'model':
            repo = self._selected_model()
            if not repo:
                return
            t, rid = repo
            if not messagebox.askyesno("Delete", f"DELETE model {rid}?\nThis cannot be undone!"):
                return

            def do():
                delete_repo(rid, repo_type=t)
                self._log(f"Deleted model {rid}")
                self.root.after(0, self._refresh_models)

            thread_it(do, on_err=lambda e: self._log(e))

        elif kind == 'bucket':
            bid = self._selected_bucket()
            if not bid:
                return
            if not messagebox.askyesno("Delete", f"DELETE bucket {bid}?\nThis cannot be undone!"):
                return

            def do():
                delete_bucket(bid)
                self._log(f"Deleted bucket {bid}")
                self.root.after(0, self._refresh_buckets)

            thread_it(do, on_err=lambda e: self._log(e))

    def _repo_create_model(self):
        rid = ask_string(self.root, "New Model", "Model ID (user/name):")
        if not rid:
            return
        private = messagebox.askyesno("Privacy", "Private model?")

        def do():
            create_repo(rid, repo_type="model", private=private, exist_ok=True)
            self._log(f"Created model {rid}")
            self.root.after(0, self._refresh_models)

        thread_it(do, on_err=lambda e: self._log(e))

    def _bucket_create(self):
        bid = ask_string(self.root, "New Bucket", "Bucket ID (user/name):")
        if not bid:
            return
        private = messagebox.askyesno("Privacy", "Private bucket?")

        def do():
            create_bucket(bid, private=private, exist_ok=True)
            self._log(f"Created bucket {bid}")
            self.root.after(0, self._refresh_buckets)

        thread_it(do, on_err=lambda e: self._log(e))

    def _clip_op(self, mode):
        self._log(f"Clipboard {mode} — full multi-select coming in polish pass")

    def _paste(self):
        self._log("Paste — full support coming in polish pass")


# ── Entrypoint ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not HAS_GITHUB:
        print("Note: PyGithub not installed. GitHub tab will ask you to install it.")
        print("      pip install PyGithub")
    root = Tk()
    app = HFCompanion(root)
    root.mainloop()
