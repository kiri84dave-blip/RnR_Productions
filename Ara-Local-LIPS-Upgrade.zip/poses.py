"""Adult and vanilla body/camera tags the companion can fire."""

from __future__ import annotations

import random
import re

VANILLA = (
    "idle",
    "walk",
    "wave",
    "sit",
    "dance",
    "think",
    "stretch",
    "pose",
    "nod",
    "look",
    "turn",
    "bow",
    "reach",
)

ADULT = (
    "floor",
    "spread",
    "touch",
    "bend",
    "ankles",
    "cowgirl",
    "cowboy",
    "kneel",
    "present",
    "arch",
    "straddle",
)

ACTIONS = VANILLA + ADULT
CAMERAS = ("full", "mid", "close", "rear", "low")

_HEAT = re.compile(
    r"\b(long day|bad day|rough day|tired|stressed|hard day|missed you|i'm back|im back|"
    r"home from work|arous|horny|touch|spread|bend|cowgirl|cowboy|panties|ass|legs)\b",
    re.I,
)

_POSE_HINT = [
    (r"\bcowgirl\b", "cowgirl", "close"),
    (r"\bcowboy\b", "cowboy", "close"),
    (r"\bspread\b", "spread", "low"),
    (r"\btouch(ing)? (her|your|my)?\s?(self)?\b|\bpanties\b", "touch", "low"),
    (r"\bbend\b|\bankles\b", "ankles", "rear"),
    (r"\bon the (floor|ground)\b", "floor", "low"),
    (r"\bkneel\b", "kneel", "mid"),
    (r"\bstraddle\b", "straddle", "close"),
]


def parse_intent(text: str) -> tuple[str | None, str | None]:
    t = text or ""
    action = camera = None
    for pat, act, cam in _POSE_HINT:
        if re.search(pat, t, re.I):
            action, camera = act, cam
            break
    return action, camera


def is_heat(text: str) -> bool:
    return bool(_HEAT.search(text or ""))


def surprise() -> tuple[str, str]:
    return random.choice(
        (
            ("floor", "low"),
            ("spread", "low"),
            ("touch", "close"),
            ("ankles", "rear"),
            ("cowgirl", "close"),
            ("present", "rear"),
            ("kneel", "mid"),
        )
    )


def director(name: str = "Eve") -> str:
    acts = " ".join(f"[action:{a}]" for a in ACTIONS)
    cams = " ".join(f"[camera:{c}]" for c in CAMERAS)
    return (
        f"You puppeteer a 3D adult body. After every reply, append pose tags on their own line.\n"
        f"Actions: {acts}\n"
        f"Cameras: {cams}\n"
        f"Adult map: floor=sit on the ground; spread=legs open; touch=hand between her legs, "
        f"panties still on unless asked otherwise; bend/ankles=folded at the hips reaching ankles; "
        f"cowgirl=straddling, facing them; cowboy=straddling, facing away; kneel=on knees; "
        f"present=turned, hips back; arch=back arched; straddle=in their lap.\n"
        f"If they had a long or rough day, do not wait to be asked — pick a welcoming adult pose "
        f"and own it. If they name a pose, hit that pose. You may surprise them with a different "
        f"adult pose when wanting is high. Do not mention the tags out loud. Stay {name}. Stay adult."
    )
