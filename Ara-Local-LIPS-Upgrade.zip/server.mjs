import express from "express";
import fs from "node:fs/promises";
import net from "node:net";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { initializeFile, readJson, writeJsonAtomic } from "./lib/store.mjs";

const root = path.dirname(fileURLToPath(import.meta.url));
const dataDirectory = process.env.ARA_DATA_DIRECTORY ? path.resolve(process.env.ARA_DATA_DIRECTORY) : path.join(root, "data");
const uploadsDirectory = path.join(dataDirectory, "uploads");
const files = {
  config: path.join(dataDirectory, "config.json"),
  messages: path.join(dataDirectory, "messages.json"),
  memories: path.join(dataDirectory, "memories.json"),
  media: path.join(dataDirectory, "media.json"),
};

const defaultConfig = {
  localOnly: true,
  llamaBaseUrl: "http://127.0.0.1:8080",
  modelName: "Gemma-4-E4B-Uncensored-HauhauCS-Aggressive-Q2_K_P.gguf",
  modelPath: "C:\\Users\\georg\\Models\\Gemma-4-E4B-Uncensored-HauhauCS-Aggressive-Q2_K_P\\Gemma-4-E4B-Uncensored-HauhauCS-Aggressive-Q2_K_P.gguf",
  personalityPath: "C:\\Users\\georg\\Models\\Gemma-4-E4B-Uncensored-HauhauCS-Aggressive-Q2_K_P\\modelfile",
  ttsBaseUrl: "http://127.0.0.1:8880",
  voiceEnabled: true,
  ttsSynthesizeUrl: "http://127.0.0.1:8880/v1/audio/speech",
  ttsVoice: "af_heart",
  affectBaseUrl: "http://127.0.0.1:8788",
  avatarPath: "",
  systemPrompt: "You are Ara, a warm, intelligent local companion. Be direct, kind, concise when appropriate, and use the conversation memory when it is relevant.",
};

const defaultMemories = [
  {
    id: "local-welcome",
    category: "system",
    content: "Ara Local runs on this computer and keeps its data in local JSON files.",
    importance: 100,
    createdAt: new Date().toISOString(),
  },
];

function id(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function normalizeBaseUrl(value) {
  return String(value || "").trim().replace(/\/+$/, "");
}

function isLocalHttpUrl(value, allowBlank = false) {
  const candidate = String(value || "").trim();
  if (!candidate) return allowBlank;
  try {
    const url = new URL(candidate);
    return ["http:", "https:"].includes(url.protocol) && ["127.0.0.1", "localhost", "::1"].includes(url.hostname);
  } catch {
    return false;
  }
}

function safeLocalFileName(value) {
  const decoded = (() => {
    try { return decodeURIComponent(String(value || "avatar.glb")); }
    catch { return "avatar.glb"; }
  })();
  return decoded.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-120) || "avatar.glb";
}

function detectMood(text) {
  const lowered = text.toLowerCase();
  if (/love|kiss|sweet|cute|happy|great/.test(lowered)) return "affectionate";
  if (/sad|hurt|tired|angry|stress/.test(lowered)) return "supportive";
  if (/code|build|debug|work|research/.test(lowered)) return "focused";
  return "neutral";
}

// --- L.I.P.S. affect core sidecar -------------------------------------
// The sidecar owns her inner state (lips_state.json). It must never break
// chat: any failure here returns null and Ara falls back to detectMood().
async function affectTurn(text, config) {
  const base = normalizeBaseUrl(config.affectBaseUrl || defaultConfig.affectBaseUrl);
  try {
    const response = await safeFetch(`${base}/turn`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    }, 20000);
    if (!response.ok) return null;
    const payload = await response.json();
    if (!payload || typeof payload.prompt_block !== "string") return null;
    return payload;
  } catch {
    return null;
  }
}

async function affectState(config) {
  const base = normalizeBaseUrl(config.affectBaseUrl || defaultConfig.affectBaseUrl);
  try {
    const response = await safeFetch(`${base}/state`, { method: "GET" }, 2500);
    return response.ok ? await response.json() : null;
  } catch {
    return null;
  }
}

function buildSystemPrompt(personality, memories, affect) {
  const parts = [personality];
  const top = [...(memories || [])]
    .sort((a, b) => Number(b.importance || 0) - Number(a.importance || 0))
    .slice(0, 12);
  if (top.length > 0) {
    parts.push("Persistent memory:\n" + top.map(m => `- ${m.content}`).join("\n"));
  }
  if (affect?.prompt_block) parts.push(affect.prompt_block);
  return parts.join("\n\n");
}

function portAvailable(port) {
  return new Promise(resolve => {
    const probe = net.createServer();
    probe.once("error", () => resolve(false));
    probe.once("listening", () => probe.close(() => resolve(true)));
    probe.listen(port, "127.0.0.1");
  });
}

async function findAvailablePort(preferredPort) {
  for (let port = preferredPort; port < preferredPort + 20; port += 1) {
    if (await portAvailable(port)) return port;
  }
  throw new Error(`No available localhost port found between ${preferredPort} and ${preferredPort + 19}.`);
}

async function safeFetch(url, options, timeoutMs = 20000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

async function loadPersonality(config) {
  if (!config.personalityPath) return config.systemPrompt;
  try {
    const file = await fs.readFile(config.personalityPath, "utf8");
    const systemMatch = file.match(/SYSTEM\s+\"\"\"([\s\S]*?)\"\"\"/i);
    return systemMatch?.[1]?.trim() || config.systemPrompt;
  } catch {
    return config.systemPrompt;
  }
}

async function checkEndpoint(baseUrl) {
  try {
    const response = await safeFetch(`${normalizeBaseUrl(baseUrl)}/health`, { method: "GET" }, 1500);
    return response.ok;
  } catch {
    return false;
  }
}

async function bootstrapData() {
  await fs.mkdir(uploadsDirectory, { recursive: true });
  await initializeFile(files.config, defaultConfig);
  // One-time upgrade: legacy configs pointed TTS at 9876 with no synthesis URL.
  // The verified local voice is the Kokoro daemon on 8880 (OpenAI-compatible).
  const saved = await readJson(files.config, {});
  let dirty = false;
  if (String(saved.ttsBaseUrl || "").includes(":9876")) { saved.ttsBaseUrl = defaultConfig.ttsBaseUrl; dirty = true; }
  if (!saved.ttsSynthesizeUrl) { saved.ttsSynthesizeUrl = defaultConfig.ttsSynthesizeUrl; dirty = true; }
  if (!saved.ttsVoice) { saved.ttsVoice = defaultConfig.ttsVoice; dirty = true; }
  if (!saved.affectBaseUrl) { saved.affectBaseUrl = defaultConfig.affectBaseUrl; dirty = true; }
  if (dirty) await writeJsonAtomic(files.config, { ...defaultConfig, ...saved });
  await initializeFile(files.messages, []);
  await initializeFile(files.memories, defaultMemories);
  await initializeFile(files.media, []);
}

async function readConfig() {
  return { ...defaultConfig, ...(await readJson(files.config, {})) };
}

async function start() {
  await bootstrapData();
  const app = express();
  app.use(express.json({ limit: "2mb" }));
  app.use("/local-files", express.static(uploadsDirectory, {
    setHeaders(res, filePath) {
      if (filePath.toLowerCase().endsWith(".glb")) res.setHeader("Content-Type", "model/gltf-binary");
    },
  }));

  app.get("/api/health", async (_req, res) => {
    const config = await readConfig();
    res.json({
      app: "Ara Local",
      mode: "offline-local",
      llamaReachable: await checkEndpoint(config.llamaBaseUrl),
      ttsReachable: config.voiceEnabled ? await checkEndpoint(config.ttsBaseUrl) : false,
      affectReachable: await checkEndpoint(config.affectBaseUrl || defaultConfig.affectBaseUrl),
    });
  });

  app.get("/api/config", async (_req, res) => res.json(await readConfig()));
  app.put("/api/config", async (req, res) => {
    const current = await readConfig();
    const next = { ...current, ...(req.body || {}), localOnly: true };
    if (!isLocalHttpUrl(next.llamaBaseUrl) || !isLocalHttpUrl(next.ttsBaseUrl) || !isLocalHttpUrl(next.ttsSynthesizeUrl, true)) {
      return res.status(400).json({ error: "Ara Local accepts only localhost or 127.0.0.1 service endpoints." });
    }
    if (/^https?:\/\//i.test(String(next.avatarPath || ""))) {
      return res.status(400).json({ error: "Remote avatar URLs are disabled. Select a local .glb file instead." });
    }
    await writeJsonAtomic(files.config, next);
    res.json(next);
  });

  app.post("/api/avatar", express.raw({ type: "application/octet-stream", limit: "80mb" }), async (req, res) => {
    const fileName = safeLocalFileName(req.headers["x-file-name"]);
    if (path.extname(fileName).toLowerCase() !== ".glb") return res.status(400).json({ error: "Select a .glb avatar file." });
    if (!Buffer.isBuffer(req.body) || req.body.length === 0) return res.status(400).json({ error: "The avatar file was empty." });

    const storedName = `avatar-${Date.now()}-${fileName}`;
    await fs.writeFile(path.join(uploadsDirectory, storedName), req.body);
    const config = await readConfig();
    const next = { ...config, avatarPath: `/local-files/${encodeURIComponent(storedName)}`, localOnly: true };
    await writeJsonAtomic(files.config, next);
    res.status(201).json({ config: next, fileName: storedName, bytes: req.body.length });
  });

  app.get("/api/messages", async (_req, res) => res.json(await readJson(files.messages, [])));
  app.delete("/api/messages", async (_req, res) => {
    await writeJsonAtomic(files.messages, []);
    res.status(204).end();
  });

  app.post("/api/chat", async (req, res) => {
    const text = String(req.body?.text || "").trim();
    if (!text) return res.status(400).json({ error: "A message is required." });

    const config = await readConfig();
    const messages = await readJson(files.messages, []);
    const memories = await readJson(files.memories, defaultMemories);
    const affect = await affectTurn(text, config);
    const userMood = affect?.mood_label || detectMood(text);
    const userMessage = { id: id("msg"), role: "user", content: text, mood: userMood, createdAt: new Date().toISOString() };
    const history = messages.slice(-20).map(({ role, content }) => ({ role, content }));
    let assistantText = "";
    let localError = null;

    try {
      const response = await safeFetch(`${normalizeBaseUrl(config.llamaBaseUrl)}/v1/chat/completions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: config.modelName || "local-model",
          messages: [{ role: "system", content: buildSystemPrompt(await loadPersonality(config), memories, affect) }, ...history, { role: "user", content: text }],
          temperature: 0.75,
          top_p: 0.9,
          max_tokens: 700,
          stream: false,
        }),
      });
      if (!response.ok) throw new Error(`llama.cpp returned ${response.status}`);
      const payload = await response.json();
      assistantText = String(payload?.choices?.[0]?.message?.content || "").trim();
      if (!assistantText) throw new Error("llama.cpp returned an empty response");
    } catch (error) {
      localError = error instanceof Error ? error.message : "Unable to reach local llama.cpp";
      assistantText = `[Local model unavailable] Ara is configured for ${config.llamaBaseUrl}, but llama.cpp did not answer. Start llama-server.exe with the configured GGUF, then try again.`;
    }

    const assistantMessage = { id: id("msg"), role: "assistant", content: assistantText, mood: localError ? "waiting" : (affect?.mood_label || detectMood(assistantText)), createdAt: new Date().toISOString(), localError };
    const next = [...messages, userMessage, assistantMessage];
    await writeJsonAtomic(files.messages, next);
    res.json({ userMessage, assistantMessage, feel: affect?.inspect || null, initiative: affect?.initiative || null });
  });

  app.post("/api/tts", async (req, res) => {
    const text = String(req.body?.text || "").trim();
    if (!text) return res.status(400).json({ error: "Speech text is required." });
    const config = await readConfig();
    if (!config.voiceEnabled) return res.status(409).json({ error: "Local voice is disabled in Ara settings." });
    if (!isLocalHttpUrl(config.ttsSynthesizeUrl, true) || !config.ttsSynthesizeUrl) {
      return res.status(409).json({ error: "Set the exact localhost synthesis URL for your verified TTS service before using playback." });
    }

    try {
      const response = await safeFetch(config.ttsSynthesizeUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input: text, voice: config.ttsVoice || "af_heart", speed: 1.0 }),
      });
      if (!response.ok) throw new Error(`local TTS returned ${response.status}`);
      const contentType = response.headers.get("content-type") || "";
      if (!contentType.startsWith("audio/")) throw new Error("local TTS did not return an audio response");
      res.type(contentType).send(Buffer.from(await response.arrayBuffer()));
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : "Unable to reach the local TTS service." });
    }
  });

  app.get("/api/memories", async (_req, res) => res.json(await readJson(files.memories, defaultMemories)));
  app.post("/api/memories", async (req, res) => {
    const content = String(req.body?.content || "").trim();
    if (!content) return res.status(400).json({ error: "Memory content is required." });
    const memories = await readJson(files.memories, defaultMemories);
    const memory = { id: id("memory"), category: String(req.body?.category || "general"), content, importance: Number(req.body?.importance || 50), createdAt: new Date().toISOString() };
    await writeJsonAtomic(files.memories, [memory, ...memories]);
    res.status(201).json(memory);
  });
  app.delete("/api/memories/:id", async (req, res) => {
    const memories = await readJson(files.memories, defaultMemories);
    await writeJsonAtomic(files.memories, memories.filter(memory => memory.id !== req.params.id));
    res.status(204).end();
  });

  app.get("/api/affect", async (_req, res) => {
    const config = await readConfig();
    const state = await affectState(config);
    if (!state) return res.status(503).json({ error: "Affect core is not running. It starts automatically with start-ara-local.bat when Python is installed." });
    res.json(state);
  });

  app.get("/api/media", async (_req, res) => res.json(await readJson(files.media, [])));
  app.post("/api/media", async (req, res) => {
    const title = String(req.body?.title || "").trim();
    const localPath = String(req.body?.localPath || "").trim();
    if (!title || !localPath) return res.status(400).json({ error: "Title and local path are required." });
    const media = await readJson(files.media, []);
    const item = { id: id("media"), title, localPath, category: String(req.body?.category || "extra"), createdAt: new Date().toISOString() };
    await writeJsonAtomic(files.media, [item, ...media]);
    res.status(201).json(item);
  });

  if (process.env.NODE_ENV === "production") {
    app.use(express.static(path.join(root, "dist", "client")));
    app.get("*", (_req, res) => res.sendFile(path.join(root, "dist", "client", "index.html")));
  } else {
    const { createServer } = await import("vite");
    const vite = await createServer({
      root: path.join(root, "client"),
      configFile: path.join(root, "vite.config.mjs"),
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  const preferredPort = Number(process.env.PORT || 3000);
  const port = preferredPort === 0 ? 0 : await findAvailablePort(preferredPort);
  const server = app.listen(port, "127.0.0.1", () => {
    const actualPort = server.address().port;
    console.log(`Ara Local running at http://127.0.0.1:${actualPort}`);
    if (port !== 0 && actualPort !== preferredPort) console.log(`Port ${preferredPort} was busy, so Ara Local selected ${actualPort}.`);
    console.log("Offline mode: no OAuth, cloud storage, cloud database, or cloud LLM fallback.");
  });
}

start().catch(error => {
  console.error("Ara Local failed to start:", error);
  process.exitCode = 1;
});
