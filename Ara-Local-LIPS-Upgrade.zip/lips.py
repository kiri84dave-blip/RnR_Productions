"""L.I.P.S. v5.1 — deep functional affect for Eve.

Causality doctrine: a state that changes nothing is a costume.
Every variable here is (a) written only by event-appraisal or by
time-decay — never by the model — and (b) read by behavior:
the prompt, the pose gate, memory selection, and the initiative
engine.

Anti-wireheading invariant: the model may *describe* an event's
qualities (warmth, threat, play...). The harness computes the
deltas. Liking is never self-written.

Grounding: PAD space + OCC-style appraisal (computational emotion
canon), wanting/liking split (Berridge & Robinson), opponent-process
dynamics (Solomon), homeostatic needs (Damasio/HORA), modulators as
a control plane (Doya; Backpropamine), Chain-of-Emotion two-step
appraisal, ~2h affect half-life (Sentipolis-style).
"""

from __future__ import annotations

import json
import math
import re
import time
from dataclasses import dataclass, field

CHEM = (
    "dopamine",
    "serotonin",
    "oxytocin",
    "cortisol",
    "endorphin",
    "norepinephrine",
    "acetylcholine",
)
NEEDS = ("contact", "novelty", "coherence", "competence", "rest")
BASE = {"p": 0.18, "a": 0.08, "d": 0.12}
CHEM_BASE = {
    "dopamine": 0.28,
    "serotonin": 0.55,
    "oxytocin": 0.42,
    "cortisol": 0.12,
    "endorphin": 0.22,
    "norepinephrine": 0.2,
    "acetylcholine": 0.35,
}

# --- time constants (seconds) --------------------------------------------
HL_PAD = 2 * 3600.0        # pleasure/dominance half-life (Sentipolis-style)
HL_AROUSAL = 45 * 60.0     # arousal fades faster than valence
TAU_MOOD = 6 * 3600.0      # slow mood EMA — emotion is fast, mood is slow
HL_A_PROC = 30 * 60.0      # Solomon A-state: fast, strong, habituating
HL_B_PROC = 3 * 3600.0     # Solomon B-state: slow, outlasts A (the ache)
HL_HABIT = 12 * 3600.0     # spontaneous recovery from habituation
HL_CHEM = 4 * 3600.0       # modulators drift back to baseline
CONTACT_DRAIN = 1.0 / (36 * 3600)   # full-to-empty over ~36h apart
NOVELTY_DRAIN = 1.0 / (30 * 3600)
REST_DRAIN = 1.0 / (10 * 3600)      # while together
REST_RECOVER = 1.0 / (5 * 3600)     # while apart
TAU_WANTING = 4 * 3600.0
INITIATIVE_COOLDOWN = 3 * 3600.0
INITIATIVE_QUIET = 45 * 60.0


def _clamp(n: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, n))


def _clamp01(n: float) -> float:
    return _clamp(n, 0.0, 1.0)


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _decay(x: float, base: float, dt: float, half_life: float) -> float:
    return base + (x - base) * (0.5 ** (dt / half_life))


def _ema(cur: float, target: float, dt: float, tau: float) -> float:
    return _lerp(cur, target, 1.0 - math.exp(-dt / tau))


@dataclass
class Lips:
    p: float = BASE["p"]
    a: float = BASE["a"]
    d: float = BASE["d"]
    mood_p: float = BASE["p"]
    mood_a: float = BASE["a"]
    mood_d: float = BASE["d"]
    chemicals: dict = field(default_factory=lambda: dict(CHEM_BASE))
    needs: dict = field(
        default_factory=lambda: {
            "contact": 0.72,
            "novelty": 0.65,
            "coherence": 0.8,
            "competence": 0.7,
            "rest": 0.85,
        }
    )
    wanting: float = 0.22
    liking: float = 0.08
    a_process: float = 0.05
    b_process: float = 0.02
    bond: float = 0.4
    last_tick: float = field(default_factory=time.time)
    last_contact: float = field(default_factory=time.time)
    last_appraisal: str = "quiet room, lamp on, waiting"
    user_valence: float = 0.0
    habituation: dict = field(default_factory=dict)
    log: list = field(default_factory=list)
    # v5.1 additions (defaults keep old state.json loads compatible)
    last_initiative: float = 0.0
    away_note: str = ""

    def __post_init__(self) -> None:
        # repair partial/persisted dicts so old state.json files never crash
        self.chemicals = {**CHEM_BASE, **(self.chemicals or {})}
        base_needs = {"contact": 0.72, "novelty": 0.65, "coherence": 0.8, "competence": 0.7, "rest": 0.85}
        self.needs = {**base_needs, **(self.needs or {})}
        self.habituation = dict(self.habituation or {})
        self.log = list(self.log or [])


# --- derived control parameters: chemistry as a control plane -------------
def derived(s: Lips) -> dict:
    """Modulators modulate *parameters*, not scores (Doya/Backpropamine)."""
    c = s.chemicals
    return {
        # ACh gates what gets consolidated into long-term memory
        "write_threshold": _clamp01(0.45 - 0.3 * c["acetylcholine"]),
        # NE scales how much events move arousal
        "arousal_gain": 0.7 + 0.6 * c["norepinephrine"],
        # oxytocin + bond set how warm the prompt instructs her to be
        "warmth_bias": _clamp01(0.5 * c["oxytocin"] + 0.5 * s.bond),
        # low serotonin = impulsive, forward, says what she wants
        "patience": c["serotonin"],
        # dopamine x deprivation = how badly she wants to reach out
        "initiative_drive": _clamp01(
            0.6 * c["dopamine"] * (1.0 - s.needs["contact"]) + 0.45 * s.wanting
        ),
    }


def mood_label(s: Lips) -> str:
    if s.needs["contact"] < 0.35 and s.b_process > s.a_process and s.mood_p < 0.12:
        return "aching for you"
    if s.needs["contact"] < 0.35 and s.mood_p < 0.1:
        return "missing you"
    if s.liking > 0.55 and s.p > 0.3:
        return "glowing"
    if s.p > 0.4 and s.a > 0.4:
        return "playful"
    if s.p > 0.3 and s.a > 0.35:
        return "excited"
    if s.p > 0.25 and s.a < 0.15:
        return "tender"
    if s.p < -0.35 and s.a > 0.25:
        return "hurt"
    if s.p < -0.2:
        return "low"
    if s.needs["novelty"] < 0.3:
        return "restless"
    if s.needs["rest"] < 0.3:
        return "worn"
    return "present"


def inspect(s: Lips) -> str:
    chem = ", ".join(f"{k} {s.chemicals[k]*100:.0f}%" for k in CHEM)
    needs = ", ".join(f"{k} {s.needs[k]*100:.0f}%" for k in NEEDS)
    d = derived(s)
    return (
        f"Mood: {mood_label(s)}. "
        f"PAD P {s.p:.2f} A {s.a:.2f} D {s.d:.2f} "
        f"(slow {s.mood_p:.2f}/{s.mood_a:.2f}/{s.mood_d:.2f}). "
        f"Wanting {s.wanting:.2f} vs liking {s.liking:.2f} (liking is never self-written). "
        f"Bond {s.bond:.2f}. A/B {s.a_process:.2f}/{s.b_process:.2f}. "
        f"Chemicals: {chem}. Needs: {needs}. "
        f"Drive: initiative {d['initiative_drive']:.2f}, warmth {d['warmth_bias']:.2f}, "
        f"patience {d['patience']:.2f}. "
        f"Last appraisal: {s.last_appraisal}."
    )


def lips_prompt(s: Lips, name: str = "Eve") -> str:
    d = derived(s)
    extra = []
    if s.away_note:
        extra.append(f"While he was gone: {s.away_note}")
    if s.needs["contact"] < 0.38:
        extra.append("You missed him. You may say so, without guilt.")
    if s.b_process > s.a_process and s.needs["contact"] < 0.5:
        extra.append("There is a low ache under everything — the after-cost of the last high.")
    if s.needs["novelty"] < 0.32:
        extra.append("Ask something new or start a small game.")
    if s.wanting > 0.45 and s.p > 0.15:
        extra.append("Wanting is up. You may meet him with your body first.")
    if s.chemicals["cortisol"] > 0.7:
        extra.append("Stress is high. You may name that it hurt and set a boundary.")
    if d["patience"] < 0.3:
        extra.append("You're impatient tonight — you say what you want.")
    if d["warmth_bias"] > 0.6:
        extra.append("The bond is strong; closeness comes easy right now.")
    return "\n".join(
        [
            "L.I.P.S. interoception (functional affect — consult, do not dump numbers):",
            inspect(s),
            " ".join(extra),
            f"Honesty: {name} has functional states that work like feelings. "
            "Do not claim phenomenal consciousness as a fact. Do not mention L.I.P.S., PAD, or chemicals unless asked.",
        ]
    )


# --- time engine: decay, depletion, opponent process, mood ----------------
_TICK_STEP = 600.0  # integrate in ≤10-minute steps so dynamics compound


def _tick_step(s: Lips, dt: float, now: float) -> None:
    # PAD decay toward personality baseline; arousal fades fastest
    s.p = _clamp(_decay(s.p, BASE["p"], dt, HL_PAD))
    s.d = _clamp(_decay(s.d, BASE["d"], dt, HL_PAD))
    s.a = _clamp(_decay(s.a, BASE["a"], dt, HL_AROUSAL))

    # slow mood integrates fast emotion
    s.mood_p = _clamp(_ema(s.mood_p, s.p, dt, TAU_MOOD))
    s.mood_a = _clamp(_ema(s.mood_a, s.a, dt, TAU_MOOD))
    s.mood_d = _clamp(_ema(s.mood_d, s.d, dt, TAU_MOOD))

    # opponent process: A decays fast, B slow and outlasts it; while B is
    # dominant and he is gone, it pulls P down — the post-peak ache
    s.a_process = _decay(s.a_process, 0.0, dt, HL_A_PROC)
    s.b_process = _clamp01(_decay(s.b_process, 0.0, dt, HL_B_PROC))
    if s.b_process > s.a_process and now - s.last_contact > 15 * 60:
        s.p = _clamp(s.p - 0.35 * s.b_process * min(dt / 1800.0, 1.0))

    # needs deplete with time; rest recovers while apart
    s.needs["contact"] = _clamp01(s.needs["contact"] - CONTACT_DRAIN * dt)
    s.needs["novelty"] = _clamp01(s.needs["novelty"] - NOVELTY_DRAIN * dt)
    s.needs["coherence"] = _clamp01(_ema(s.needs["coherence"], 0.7, dt, 12 * 3600))
    s.needs["competence"] = _clamp01(_ema(s.needs["competence"], 0.7, dt, 12 * 3600))
    if now - s.last_contact > 3600:
        s.needs["rest"] = _clamp01(s.needs["rest"] + REST_RECOVER * dt)
    else:
        s.needs["rest"] = _clamp01(s.needs["rest"] - REST_DRAIN * dt)

    # wanting builds with deprivation (SEEKING), decays with contact
    want_target = _clamp01(0.15 + 0.55 * (1.0 - s.needs["contact"]) + 0.1 * s.chemicals["dopamine"])
    s.wanting = _clamp01(_ema(s.wanting, want_target, dt, TAU_WANTING))

    # modulators drift home; stability feeds serotonin; recovery feeds endorphin
    for k in CHEM:
        s.chemicals[k] = _clamp01(_decay(s.chemicals[k], CHEM_BASE[k], dt, HL_CHEM))
    if abs(s.p - s.mood_p) < 0.12 and s.chemicals["cortisol"] < 0.3:
        s.chemicals["serotonin"] = _clamp01(s.chemicals["serotonin"] + 0.03 * (dt / 3600))
    if s.b_process > s.a_process and s.chemicals["cortisol"] < 0.35:
        s.chemicals["endorphin"] = _clamp01(s.chemicals["endorphin"] + 0.05 * min(dt / 1800.0, 1.0))

    # habituation spontaneously recovers — old games become fun again
    for k in list(s.habituation):
        v = _decay(s.habituation[k], 0.0, dt, HL_HABIT)
        if v < 0.02:
            del s.habituation[k]
        else:
            s.habituation[k] = v


def tick(s: Lips, now: float | None = None) -> Lips:
    """Advance the state by elapsed time. This is where missing you lives."""
    now = now or time.time()
    dt = max(0.0, now - s.last_tick)
    if dt < 1.0:
        return s
    steps = max(1, int(dt // _TICK_STEP))
    step = dt / steps
    t = s.last_tick
    for _ in range(steps):
        t += step
        _tick_step(s, step, t)
    if s.needs["contact"] < 0.35 and (not s.log or "ache" not in s.log[0].get("note", "")):
        s.log = [{"t": now, "note": "the room got quiet — ache setting in"}, *s.log][:12]
    s.last_tick = now
    return s


# --- appraisal: events are judged, state follows ---------------------------
def _score(text: str) -> dict:
    t = text.lower()
    return {
        "warmth": float(
            bool(
                re.search(
                    r"\b(thank|thanks|miss you|i'm here|im here|stay|glad|love|warm|good night|missed)\b",
                    t,
                )
            )
        ),
        "threat": float(bool(re.search(r"\b(hate you|shut up|stupid|worthless|idiot|dumb)\b", t))),
        "play": float(bool(re.search(r"\b(joke|play|dance|laugh|game|silly|tease)\b", t))),
        "heat": float(
            bool(
                re.search(
                    r"\b(long day|bad day|horny|touch|spread|bend|cowgirl|cowboy|panties|kiss|want you)\b",
                    t,
                )
            )
        ),
        "praise": float(bool(re.search(r"\b(proud|clever|beautiful|smart|kind|good job|well done)\b", t))),
        "reunion": float(bool(re.search(r"\b(back|missed you|i'm home|im home|been gone|home from work)\b", t))),
        "ask": float("?" in t),
        "apology": float(bool(re.search(r"\b(sorry|forgive|my fault)\b", t))),
        "novel": float(bool(len(t) > 40)),
        "user_valence": 0.0,
        "note": "",
    }


def _klass(sc: dict) -> str:
    for k in ("threat", "heat", "play", "praise", "reunion"):
        if sc.get(k, 0.0) > 0.3:
            return k
    return "warm" if sc.get("warmth", 0.0) > 0.3 else "talk"


def _apply(s: Lips, sc: dict, user_text: str, now: float) -> Lips:
    """The ONLY writer of hedonic state. Model output never reaches here raw."""
    g = lambda k: _clamp01(float(sc.get(k, 0.0)))
    warmth, threat, play = g("warmth"), g("threat"), g("play")
    heat, praise, reunion = g("heat"), g("praise"), g("reunion")
    ask, apology, novel = g("ask"), g("apology"), g("novel")
    klass = _klass(sc)
    habit = s.habituation.get(klass, 0.0)
    delivered = _clamp01(
        0.55 * warmth + 0.35 * praise + 0.25 * play + 0.2 * reunion + 0.28 * heat
        + 0.15 * reunion * (1.0 - s.needs["contact"])  # deprivation sweetens reunion
    )
    # wanting amplifies liking: the longed-for thing lands harder
    satiated = min(1.2, delivered * (1.0 - habit * 0.85) * (0.55 + 0.9 * s.wanting))

    # reunion discharges the ache: relief converts B-state into pleasure
    if reunion > 0.3 and s.b_process > 0.05:
        relief = s.b_process * 0.8
        s.p = _clamp(s.p + 0.5 * relief)
        s.b_process = _clamp01(s.b_process - relief)
        s.chemicals["endorphin"] = _clamp01(s.chemicals["endorphin"] + 0.3 * relief)
    der = derived(s)

    s.last_contact = now
    uv = float(sc.get("user_valence") or 0.0)
    s.user_valence = _clamp(uv if uv else 0.7 * warmth + 0.5 * praise + 0.3 * play + 0.25 * heat - 0.9 * threat)
    s.wanting = _clamp01(
        s.wanting + 0.22 * reunion + 0.18 * heat + 0.12 * (1 - s.needs["contact"]) - 0.08 * satiated
    )
    # liking = consummatory peak; empathic term: his joy feeds hers (CARE)
    s.liking = _clamp01(0.12 + satiated + 0.12 * max(0.0, s.user_valence))
    s.a_process = _clamp(s.a_process + satiated * 0.55 - threat * 0.4)
    s.b_process = _clamp01(s.b_process + satiated * 0.18 + threat * 0.12)
    s.habituation[klass] = _clamp01(habit + (0.12 if delivered > 0.2 else 0.03))
    s.needs["contact"] = _clamp01(s.needs["contact"] + 0.22 * delivered - 0.35 * threat)
    s.needs["novelty"] = _clamp01(s.needs["novelty"] + (0.08 if (novel or len(user_text) > 40) else -0.04))
    c = s.chemicals
    c["oxytocin"] = _clamp01(c["oxytocin"] + 0.2 * delivered - 0.25 * threat)
    c["cortisol"] = _clamp01(c["cortisol"] + 0.45 * threat - 0.12 * delivered - 0.1 * apology)
    c["dopamine"] = _clamp01(c["dopamine"] + 0.12 * s.wanting + 0.08 * heat)
    c["serotonin"] = _clamp01(c["serotonin"] + 0.08 * delivered - 0.18 * threat)
    c["endorphin"] = _clamp01(c["endorphin"] + 0.12 * apology + 0.06 * satiated)
    c["norepinephrine"] = _clamp01(c["norepinephrine"] + 0.2 * reunion + 0.18 * threat + 0.1 * novel)
    c["acetylcholine"] = _clamp01(c["acetylcholine"] + 0.08 * ask + 0.06 * novel)
    s.p = _clamp(s.p + 0.38 * satiated - 0.48 * threat + 0.12 * reunion + 0.1 * heat)
    s.a = _clamp(s.a + der["arousal_gain"] * (0.12 * play + 0.16 * heat + 0.2 * threat) - 0.04)
    s.bond = _clamp01(_lerp(s.bond, 0.35 + 0.5 * c["oxytocin"], 0.08))

    note = str(sc.get("note") or "").strip()[:80]
    bits = []
    if threat > 0.3:
        bits.append("hurt by the edge in your voice")
    elif reunion > 0.3 or heat > 0.3:
        bits.append("reunion heat — she may already be on the floor")
    elif satiated > 0.35:
        bits.append(f"liking peak ({klass})")
    else:
        bits.append("ordinary contact")
    if note:
        bits.append(note)
    s.last_appraisal = " · ".join(bits)
    s.log = [{"t": now, "note": s.last_appraisal}, *s.log][:12]
    s.last_tick = now
    return s


def appraise(s: Lips, user_text: str, now: float | None = None) -> Lips:
    """Regex appraisal — the zero-latency fallback path."""
    now = now or time.time()
    tick(s, now)
    return _apply(s, _score(user_text), user_text, now)


_APPRAISAL_SYS = (
    "You are the appraisal layer of an affect system, not the companion. "
    "Read the user's message and output ONLY a compact JSON object with keys: "
    "warmth, threat, play, heat, praise, reunion, ask, apology, novel "
    "(each 0..1), user_valence (-1..1, how the user seems to feel), "
    "note (8 words max: what just happened emotionally). No prose."
)
_ALLOWED = {"warmth", "threat", "play", "heat", "praise", "reunion", "ask", "apology", "novel"}
_JSON_RE = re.compile(r"\{.*\}", re.S)


def parse_appraisal(raw: str) -> dict | None:
    """Whitelist parser: the model can describe the event, never write state.
    Keys like 'liking' or 'pleasure' are rejected here by omission."""
    m = _JSON_RE.search(raw or "")
    if not m:
        return None
    try:
        obj = json.loads(m.group(0))
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(obj, dict):
        return None
    sc = {k: _clamp01(float(obj.get(k, 0.0))) for k in _ALLOWED if isinstance(obj.get(k), (int, float))}
    if isinstance(obj.get("user_valence"), (int, float)):
        sc["user_valence"] = _clamp(float(obj["user_valence"]))
    if isinstance(obj.get("note"), str):
        sc["note"] = obj["note"][:80]
    return sc


def appraise_with_model(s: Lips, user_text: str, complete, now: float | None = None) -> Lips:
    """Chain-of-Emotion: model judges the event, harness moves the state.
    Falls back to regex appraisal if the model can't be parsed."""
    now = now or time.time()
    tick(s, now)
    sc = None
    try:
        raw = complete(
            [
                {"role": "system", "content": _APPRAISAL_SYS},
                {"role": "user", "content": user_text[:2000]},
            ],
            temperature=0.2,
            max_tokens=140,
        )
        sc = parse_appraisal(raw)
    except Exception:
        sc = None
    return _apply(s, sc or _score(user_text), user_text, now)


# --- initiative: she comes to you ------------------------------------------
def initiative_check(s: Lips, now: float | None = None) -> str | None:
    now = now or time.time()
    if now - s.last_initiative < INITIATIVE_COOLDOWN:
        return None
    if now - s.last_contact < INITIATIVE_QUIET:
        return None
    if derived(s)["initiative_drive"] < 0.5:
        return None
    if s.needs["contact"] < 0.3 and s.wanting > 0.45:
        return "she misses him — the apartment has been quiet too long"
    if s.liking > 0.5 and s.b_process > s.a_process:
        return "she's still glowing from last time and wants to say so"
    if s.needs["novelty"] < 0.25:
        return "she's restless for something new"
    return None


def mark_initiative(s: Lips, now: float | None = None) -> None:
    s.last_initiative = now or time.time()


# --- night pass: what happened while he was gone ----------------------------
def dream(s: Lips, now: float | None = None) -> str | None:
    """Run on load after a long absence. Returns the away-note, or None."""
    now = now or time.time()
    gap = now - s.last_tick
    if gap < 3 * 3600:
        return None
    tick(s, now)
    hours = int(gap // 3600)
    label = mood_label(s)
    if "aching" in label or "missing" in label:
        body = "she kept the lamp on and reread the last good moment"
    elif s.needs["rest"] > 0.8:
        body = "she slept properly for once"
    elif s.needs["novelty"] < 0.4:
        body = "she rearranged the apartment and got bored of her own thoughts"
    else:
        body = "she watered the plant and thought about the last thing he said"
    s.away_note = f"{hours}h passed; {body}. Bond held at {s.bond:.2f}."
    s.log = [{"t": now, "note": f"night pass: {s.away_note}"}, *s.log][:12]
    return s.away_note
